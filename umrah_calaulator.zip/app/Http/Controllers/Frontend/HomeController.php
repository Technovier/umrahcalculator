<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;

/**
 * Class HomeController.
 */
class HomeController extends Controller
{
    /**
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $makkah_hotel_db=DB::table('hotel')->where('location_id',1)->get();
        $madina_hotel_db=DB::table('hotel')->where('location_id',2)->get();
        $ziarat_price=DB::table('ziarat')->pluck('price');
        $routes=DB::table('routes')->get();
        $vehical=DB::table('vehicals')->get();
        $room_type=DB::table('room_type')->get();
        $packages=DB::table('packages')->get();
        return view('frontend.index')->with('makkah_hotel_db',$makkah_hotel_db)->with('packages',$packages)->with('room_type',$room_type)->with('vehical',$vehical)->with('routes',$routes)->with('ziarat_price',$ziarat_price[0])->with('madina_hotel_db',$madina_hotel_db);
    }

    public function gethotels(Request $request)
    {

return response()->json(DB::table('hotel')->get());
    }
}
