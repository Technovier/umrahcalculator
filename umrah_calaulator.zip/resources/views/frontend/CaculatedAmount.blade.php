@extends('frontend.layouts.app')

@section('title', app_name() . ' | ' . __('navs.general.home'))

@section('content')


<div class="container-fluid" style="padding: 10px">
        <div class="row" >
            <div class="col" style="text-align: center">
{{--                <h3 style="color: #00aced">Detailed Calculations</h3>--}}
                <h2 style="color: #00aced">Tawaf Travels & Tours PVT(LTD)</h2>
                <label>F-16/17,Hill View Arcade, 5-Davis Road ,Lahore</label> <br>
                <label>Phone:042-36315418-19, Fax:042-362711315 UAN:042-11111111893</label>
                <h4><b>Qutation  for Umrah Packagae</b></h4>
            </div>
        </div>

<div class="row">

    <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Family Information</b></div>
</div>
        <div class="row" >
            <div class="col">
Family Name:            </div>
            <div class="col" >
            {{request()->family_name}} and family (


                @if(request()->visa_adult!=null and request()->visa_adult!=0)
                    {{request()->visa_adult}} Adults
                    @endif


                @if(request()->visa_child!=null and request()->visa_child!=0)
                    and {{request()->visa_child}} Children
                @endif

                @if(request()->visa_infant!=null and request()->visa_infant!=0)
                     and {{request()->visa_infant}} Infants
                @endif

)
            </div>
        </div>



        <div class="row">
            <div class="col">
               Contact#
            </div>
            <div class="col">
                {{request()->contact}}
            </div>
        </div>



        <div class="row">
            <div class="col">
            Email:
            </div>
            <div class="col">
                {{request()->email}}
            </div>
        </div>
<div class="row">
    <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Umrah Package Details</b></div>

</div>



    <div class="row">
    <div class="col"><h5 style="font-weight: bold">Stay in Madina</h5></div>
</div>

        <div class="row info">
            <div class="col">Hotel Name</div>
            <div class="col">Room Type</div>
            <div class="col">Total Nights</div>
            <div class="col">Fare Pkr</div>
        </div>

{{--{{dd(request()->all())}}--}}


        @php($check=0)
@if(request()->has('madina_hotel'))
        @foreach(request()->madina_hotel as $md_h)
            <div class="row">

            <?php $hotel_name=DB::table('hotel')->where('id',$md_h)->value('name');
            echo '<div class="col">'.$hotel_name.'</div>';
            echo '<div class="col">'.DB::table('room_type')->where('id',request()->madina_hotel_roomtype[$check])->value('type_name').'</div>';
            echo '<div class="col">'.request()->totalnights_madina[$check].'</div>';
            $price=DB::table('hotel_room')->where('hotel_id',$md_h)->where('room_type',request()->madina_hotel_roomtype[$check])->value('price');
            echo '<div class="col">'.$price*request()->totalnights_madina[$check].'</div>'; ?>

            </div>

    @php($check++)
                @endforeach

@endif

            <div class="row">
        <div class="col"><h5 style="font-weight: bold">Stay in Makkah</h5></div>
    </div>
            <div class="row">
                <div class="col">Hotel Name</div>
                <div class="col">Room Type</div>
                <div class="col">Total Nights</div>
                <div class="col">Fare</div>
            </div>

        @php($check=0)
        @if(request()->has('makkah_hotel'))
        @foreach(request()->makkah_hotel as $mk_h)
            <div class="row">

                <?php $hotel_name=DB::table('hotel')->where('id',$mk_h)->value('name');
                echo '<div class="col">'.$hotel_name.'</div>';
                echo '<div class="col">'.DB::table('room_type')->where('id',request()->makkah_hotel_roomtype[$check])->value('type_name').'</div>';
                echo '<div class="col">'.request()->totalnights_makkah[$check].'</div>';
                $price=DB::table('hotel_room')->where('hotel_id',$mk_h)->where('room_type',request()->makkah_hotel_roomtype[$check])->value('price');
                echo '<div class="col">'.$price*request()->totalnights_makkah[$check].'</div>'; ?>

            </div>

            @php($check++)
        @endforeach
@endif

    <div class="row">
        <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Ziarat</b></div>

    </div>
    @if(request()->persons_for_ziarat!=null)
        <div class="row">
        <div class="col"><h3 style="color: #00aced">Ziarat</h3></div>
        </div>

        <div class="row">

            <div class="col">Ziarat Price</div>
            <div class="col"># of Persons</div>
            <div class="col"></div>
            <div class="col">Total</div>

        </div>


        <div class="row">
@php($ziarat=DB::table('ziarat')->value('price'))
            <div class="col"> <?php echo $ziarat; ?></div>
            <div class="col">{{request()->persons_for_ziarat}}</div>
            <div class="col"></div>
            <div class="col">{{request()->persons_for_ziarat*$ziarat}}</div>

        </div>



        @else

        <div class="row">

            <div class="col">Ziarat Not included</div>
        </div>

    @endif



























    <div class="row">
        <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Transportation</b></div>

    </div>
    @if(request()->persons_for_ziarat!=null)
        <div class="row">
            <div class="col"><h3 style="color: #00aced">Ziarat</h3></div>
        </div>

        <div class="row">

            <div class="col">Ziarat Price</div>
            <div class="col"># of Persons</div>
            <div class="col"></div>
            <div class="col">Total</div>

        </div>


        <div class="row">
            @php($ziarat=DB::table('ziarat')->value('price'))
            <div class="col"> <?php echo $ziarat; ?></div>
            <div class="col">{{request()->persons_for_ziarat}}</div>
            <div class="col"></div>
            <div class="col">{{request()->persons_for_ziarat*$ziarat}}</div>

        </div>



    @else

        <div class="row">

            <div class="col">Ziarat Not included</div>
        </div>
@endif




</div>
        @endsection