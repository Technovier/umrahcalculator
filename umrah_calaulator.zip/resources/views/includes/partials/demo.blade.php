@demo
    <div class="alert alert-info demo">
        The Application is currently in demo mode. All requests other than GET are disabled.
    </div>
@enddemo