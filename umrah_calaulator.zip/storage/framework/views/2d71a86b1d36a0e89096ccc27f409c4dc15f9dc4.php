<?php if (\Illuminate\Support\Facades\Blade::check('demo')): ?>
    <div class="alert alert-info demo">
        The Application is currently in demo mode. All requests other than GET are disabled.
    </div>
<?php endif; ?><?php /**PATH C:\wamp64\www\umrah_calaulator\resources\views/includes/partials/demo.blade.php ENDPATH**/ ?>