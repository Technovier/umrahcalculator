<?php $__env->startSection('title', app_name() . ' | ' . __('navs.general.home')); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid" style="padding: 10px">
        <div class="row" >
            <div class="col" style="text-align: center">

                <h2 style="color: #00aced">Tawaf Travels & Tours PVT(LTD)</h2>
                <label>F-16/17,Hill View Arcade, 5-Davis Road ,Lahore</label> <br>
                <label>Phone:042-36315418-19, Fax:042-362711315 UAN:042-11111111893</label>
                <h4><b>Qutation  for Umrah Packagae</b></h4>
            </div>
        </div>

<div class="row">

    <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Family Information</b></div>
</div>
        <div class="row" >
            <div class="col">
Family Name:            </div>
            <div class="col" >
            <?php echo e(request()->family_name); ?> and family (


                <?php if(request()->visa_adult!=null and request()->visa_adult!=0): ?>
                    <?php echo e(request()->visa_adult); ?> Adults
                    <?php endif; ?>


                <?php if(request()->visa_child!=null and request()->visa_child!=0): ?>
                    and <?php echo e(request()->visa_child); ?> Children
                <?php endif; ?>

                <?php if(request()->visa_infant!=null and request()->visa_infant!=0): ?>
                     and <?php echo e(request()->visa_infant); ?> Infants
                <?php endif; ?>

)
            </div>
        </div>



        <div class="row">
            <div class="col">
               Contact#
            </div>
            <div class="col">
                <?php echo e(request()->contact); ?>

            </div>
        </div>



        <div class="row">
            <div class="col">
            Email:
            </div>
            <div class="col">
                <?php echo e(request()->email); ?>

            </div>
        </div>
<div class="row">
    <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Umrah Package Details</b></div>

</div>



    <div class="row">
    <div class="col"><h5 style="font-weight: bold">Stay in Madina</h5></div>
</div>

        <div class="row info">
            <div class="col">Hotel Name</div>
            <div class="col">Room Type</div>
            <div class="col">Total Nights</div>
            <div class="col">Fare Pkr</div>
        </div>




        <?php ($check=0); ?>
<?php if(request()->has('madina_hotel')): ?>
        <?php $__currentLoopData = request()->madina_hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md_h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">

            <?php $hotel_name=DB::table('hotel')->where('id',$md_h)->value('name');
            echo '<div class="col">'.$hotel_name.'</div>';
            echo '<div class="col">'.DB::table('room_type')->where('id',request()->madina_hotel_roomtype[$check])->value('type_name').'</div>';
            echo '<div class="col">'.request()->totalnights_madina[$check].'</div>';
            $price=DB::table('hotel_room')->where('hotel_id',$md_h)->where('room_type',request()->madina_hotel_roomtype[$check])->value('price');
            echo '<div class="col">'.$price*request()->totalnights_madina[$check].'</div>'; ?>

            </div>

    <?php ($check++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

            <div class="row">
        <div class="col"><h5 style="font-weight: bold">Stay in Makkah</h5></div>
    </div>
            <div class="row">
                <div class="col">Hotel Name</div>
                <div class="col">Room Type</div>
                <div class="col">Total Nights</div>
                <div class="col">Fare</div>
            </div>

        <?php ($check=0); ?>
        <?php if(request()->has('makkah_hotel')): ?>
        <?php $__currentLoopData = request()->makkah_hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk_h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">

                <?php $hotel_name=DB::table('hotel')->where('id',$mk_h)->value('name');
                echo '<div class="col">'.$hotel_name.'</div>';
                echo '<div class="col">'.DB::table('room_type')->where('id',request()->makkah_hotel_roomtype[$check])->value('type_name').'</div>';
                echo '<div class="col">'.request()->totalnights_makkah[$check].'</div>';
                $price=DB::table('hotel_room')->where('hotel_id',$mk_h)->where('room_type',request()->makkah_hotel_roomtype[$check])->value('price');
                echo '<div class="col">'.$price*request()->totalnights_makkah[$check].'</div>'; ?>

            </div>

            <?php ($check++); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

    <div class="row">
        <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Ziarat</b></div>

    </div>
    <?php if(request()->persons_for_ziarat!=null): ?>
        <div class="row">
        <div class="col"><h3 style="color: #00aced">Ziarat</h3></div>
        </div>

        <div class="row">

            <div class="col">Ziarat Price</div>
            <div class="col"># of Persons</div>
            <div class="col"></div>
            <div class="col">Total</div>

        </div>


        <div class="row">
<?php ($ziarat=DB::table('ziarat')->value('price')); ?>
            <div class="col"> <?php echo $ziarat; ?></div>
            <div class="col"><?php echo e(request()->persons_for_ziarat); ?></div>
            <div class="col"></div>
            <div class="col"><?php echo e(request()->persons_for_ziarat*$ziarat); ?></div>

        </div>



        <?php else: ?>

        <div class="row">

            <div class="col">Ziarat Not included</div>
        </div>

    <?php endif; ?>



























    <div class="row">
        <div class="col" style="border: 1px solid black;background-color: lightgray"><b>Transportation</b></div>

    </div>
    <?php if(request()->persons_for_ziarat!=null): ?>
        <div class="row">
            <div class="col"><h3 style="color: #00aced">Ziarat</h3></div>
        </div>

        <div class="row">

            <div class="col">Ziarat Price</div>
            <div class="col"># of Persons</div>
            <div class="col"></div>
            <div class="col">Total</div>

        </div>


        <div class="row">
            <?php ($ziarat=DB::table('ziarat')->value('price')); ?>
            <div class="col"> <?php echo $ziarat; ?></div>
            <div class="col"><?php echo e(request()->persons_for_ziarat); ?></div>
            <div class="col"></div>
            <div class="col"><?php echo e(request()->persons_for_ziarat*$ziarat); ?></div>

        </div>



    <?php else: ?>

        <div class="row">

            <div class="col">Ziarat Not included</div>
        </div>
<?php endif; ?>




</div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\umrah_calaulator\resources\views/frontend/CaculatedAmount.blade.php ENDPATH**/ ?>