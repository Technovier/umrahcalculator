<footer class="app-footer">
    <div>
        <strong><?php echo app('translator')->getFromJson('labels.general.copyright'); ?> &copy; <?php echo e(date('Y')); ?>

            <a href="http://laravel-boilerplate.com">
                <?php echo app('translator')->getFromJson('strings.backend.general.boilerplate_link'); ?>
            </a>
        </strong> <?php echo app('translator')->getFromJson('strings.backend.general.all_rights_reserved'); ?>
    </div>

    <div class="ml-auto">Theme by <a href="http://coreui.io">CoreUI</a></div>
</footer>
<?php /**PATH C:\wamp64\www\umrah_calaulator\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>